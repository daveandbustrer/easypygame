# Blu Easy Pygame

Blu Easy Pygame is a small library built on top of `pygame` that simplifies the process of starting basic games. Instead of writing the same setup code repeatedly, you can just set up a window, create shapes, bind events, and start the game loop.

It includes:

- Easy window setup
- A built-in game loop
- Simple event binding
- Built-in shapes like rectangles, circles, ellipses, squares, lines, and polygons

---

# Installation

First, install `pygame`.

```bash
python -m pip install pygame
```

If you're working on the project locally:

```bash
python -m pip install -e .
```

If it's uploaded to PyPI, you can install it with:

```bash
python -m pip install Blu_easypygame
```

---

# Quick Start

```python
import Blu_easypygame as epy

# Create the game window
epy.init(width=640, height=480, bg="lightgray")

# Make some shapes
box = epy.graphics.rect(100, 100, 120, 80, color="red")
circle = epy.graphics.circle(300, 200, 50, color="blue")
line = epy.graphics.line([(50, 50), (200, 120)], width=4, color="green")
triangle = epy.graphics.polygon(
    [(350, 100), (420, 180), (320, 220)],
    color="purple"
)

def update(dt):
    box.x += 100 * dt

    if box.left > epy.getWidth():
        box.right = 0

def clicked(event):
    print("Mouse clicked!", event)

epy.bind("mainLoop", update)
epy.bind("leftMouseDown", clicked)

epy.run()
```

---

# Main Functions

### `epy.init()`

Creates the game window and starts pygame.

```python
epy.init(
    width=300,
    height=300,
    bg="white",
    background=None,
    frame=60,
    busy=False
)
```

Returns the values from `pygame.init()`.

---

### `epy.run()`

Starts the game loop. 

It continues until the window is closed or you call:

```python
epy.stop()
```

---

### `epy.bind()`

Lets you connect your own functions to events.

Example:

```python
epy.bind("mainLoop", update)
epy.bind("leftMouseDown", clicked)
```

Some supported events:

- `mainLoop`
- `physicsLoop`
- `mouseDown`
- `mouseUp`
- `leftMouseDown`
- `leftMouseUp`
- `middleMouseDown`
- `middleMouseUp`
- `rightMouseDown`
- `rightMouseUp`
- `mouseMotion`
- `mouseWheel`
- `keyDown`
- `keyUp`

---

### Other useful functions

```python
epy.unbind("mainLoop")
epy.stop()

epy.getWidth()
epy.getHeight()

epy.getFPS()
epy.getGameTime()

epy.getBackground()
epy.setBackground("black")

epy.sleep(1000)
```

---

# Shapes

All shapes are created through `epy.graphics`.

They are automatically drawn every frame, so you don't need to draw them manually.

### Rectangle

```python
epy.graphics.rect(x, y, width, height, angle=0, color="black")
```

### Circle

```python
epy.graphics.circle(x, y, radius, color="black")
```

### Ellipse

```python
epy.graphics.ellipse(x, y, width, height, angle=0, color="black")
```

### Square

```python
epy.graphics.square(x, y, radius, angle=0, color="black")
```

### Line

```python
epy.graphics.line(points, width=1, color="black")
```

### Polygon

```python
epy.graphics.polygon(points, width=0, angle=0, color="black")
```

---

# Shape Properties

Most shapes have properties you can change anytime.

Some common ones are:

- `x`
- `y`
- `left`
- `right`
- `top`
- `bottom`
- `color`
- `angle`

Some shapes also have:

- `width`
- `height`
- `radius`
- `points`

Example:

```python
box.x += 5
box.color = "blue"

print(circle.radius)
```

---

# Event Data

Mouse events give you a dictionary with information such as:

- mouse position
- which buttons are pressed
- movement
- wheel scrolling

Keyboard events include information like:

- key
- unicode
- modifiers
- scancode

Example:

```python
def on_click(event):
    print(event)

epy.bind("leftMouseDown", on_click)
```

---

# Full Example

```python
import Blu_easypygame as epy

epy.init(width=640, height=480, bg="lightgray")

player = epy.graphics.rect(50, 50, 50, 50, color="blue")

enemy = epy.graphics.polygon(
    [(400, 100), (460, 180), (340, 180)],
    color="red"
)

def update(dt):
    player.x += 120 * dt

    if player.left > epy.getWidth():
        player.right = 0

def on_click(event):
    print(event)

epy.bind("mainLoop", update)
epy.bind("leftMouseDown", on_click)

epy.run()
```
