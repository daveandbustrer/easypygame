# Blu Easy Pygame

A small wrapper for `pygame` that makes basic game setup easier.

`Blu_easypygame` provides:

- a simple `init()` function for window setup
- a single `run()` loop for frame updates
- callback binding for frame and input events
- shape factories for rectangles, circles, ellipses, lines, squares, and polygons

---

## Installation

Install `pygame` first, then install the package locally for development:

```bash
python -m pip install pygame
python -m pip install -e .
```

If published on PyPI, install with:

```bash
python -m pip install Blu_easypygame
```

---

## Quick Start

```python
import Blu_easypygame as epy

# 1. Initialize the window
epy.init(width=640, height=480, bg="lightgray")

# 2. Create shapes
box = epy.graphics.rect(100, 100, 120, 80, color="red")
circle = epy.graphics.circle(300, 200, 50, color="blue")
line = epy.graphics.line([(50, 50), (200, 120)], width=4, color="green")
polygon = epy.graphics.polygon(
    [(350, 100), (420, 180), (320, 220)],
    color="purple"
)

def update(dt):
    box.x += 100 * dt
    if box.left > epy.getWidth():
        box.right = 0

def on_left_click(event):
    print("Left click:", event)

# Bind callbacks and run
epy.bind("mainLoop", update)
epy.bind("leftMouseDown", on_left_click)
epy.run()
```

---

## Core API (summary)

- `epy.init(width=300, height=300, bg="white", background=None, frame=60, busy=False)`
  - Initialize `pygame`, configure the display, and set the background color.
  - Returns `(passed, failed)` from `pygame.init()`.

- `epy.run()` — Start the main game loop. The loop finishes when the window closes or `epy.stop()` is called.

- `epy.run()` — Start the main game loop. Runs all bound callbacks and draws shapes each frame until stopped.

- `epy.bind(funcType, func)` — Register a callback. Supported `funcType` values include:
  - `mainLoop` — called each frame with `dt` in seconds
  - `physicsLoop` — called each frame with a physics delta time
  - `phisicLoop` — legacy alias for `physicsLoop` (kept for backwards compatibility)
  - `mouseDown`, `mouseUp`, `leftMouseDown`, `leftMouseUp`, `middleMouseDown`, `middleMouseUp`, `rightMouseDown`, `rightMouseUp`
  - `mouseMotion`, `mouseWheel`, `keyDown`, `keyUp`

- `epy.unbind(funcType)` — Remove a bound callback.
- `epy.stop()` — Stop the running game loop.
- `epy.getWidth()`, `epy.getHeight()` — Return current window dimensions.
- `epy.getFPS()` — Return the current frame rate value.
- `epy.getGameTime()` — Return elapsed game time in milliseconds.
- `epy.getBackground()` / `epy.setBackground(color)` — Read or change background color.
- `epy.sleep(milliseconds, processOS=True)` — Pause execution for the given time (milliseconds).

- `epy.unbind(funcType)` — Remove a previously bound callback for `funcType`.
- `epy.stop()` — Request the loop to exit on the next frame.
- `epy.getWidth()`, `epy.getHeight()` — Return current window dimensions (pixels).
- `epy.getFPS()` — Return the measured frames per second.
- `epy.getGameTime()` — Return elapsed game time in milliseconds since `pygame.init()`.
- `epy.getBackground()` / `epy.setBackground(color)` — Get or set the current clear/background color.
- `epy.sleep(milliseconds, processOS=True)` — Pause the game loop; `processOS=True` uses `wait`, otherwise `delay`.

Examples:

```python
width = epy.getWidth()
fps = epy.getFPS()
epy.setBackground("black")
```

---

## Shapes

Create shapes with `epy.graphics`. They are drawn automatically each frame.

- `epy.graphics.rect(x, y, width, height, angle=0, color="black")`
- `epy.graphics.rect(x, y, width, height, angle=0, color="black")` — Create a rectangle shape positioned with center at `(x, y)`.
- `epy.graphics.circle(x, y, radius, color="black")` — Create a circle shape centered at `(x, y)`.
- `epy.graphics.ellipse(x, y, width, height, angle=0, color="black")` — Create an ellipse with given size and rotation.
- `epy.graphics.square(x, y, radius, angle=0, color="black")` — Create a square (radius = half side length) centered at `(x, y)`.
- `epy.graphics.line(points, width=1, color="black")` — Create a polyline connecting `points`; set `width` for stroke.
- `epy.graphics.polygon(points, width=0, angle=0, color="black")` — Create a filled (`width=0`) or stroked polygon from `points`.

Common properties on shapes:

- `x`, `y`, `left`, `right`, `top`, `bottom`
- `width`, `height` (rectangles, ellipses)
- `radius` (circles, squares)
- `points` (lines, polygons)
- `angle`, `color`

Example:

```python
rect.x += 5
rect.color = "blue"
print(circle.radius)
```

---

## Event data

Mouse callbacks receive a dictionary with keys such as `pos`, `rel`, `buttons`, `touch`, `window`, and wheel deltas `x`, `y`.

Keyboard callbacks receive `unicode`, `key`, `mod`, and `scancode` values.

Example:

```python
def on_click(event):
    print("Clicked:", event)

epy.bind("leftMouseDown", on_click)
```

---

## Full example

```python
import Blu_easypygame as epy

epy.init(width=640, height=480, bg="lightgray")

player = epy.graphics.rect(50, 50, 50, 50, color="blue")
enemy = epy.graphics.polygon(
    [(400, 100), (460, 180), (340, 180)],
    color="red"
)

def update(dt):
    player.x += 120 * dt
    if player.left > epy.getWidth():
        player.right = 0

def on_click(event):
    print("Click event:", event)

epy.bind("mainLoop", update)
epy.bind("leftMouseDown", on_click)
epy.run()
```

---

If you spot any remaining inconsistencies or want the README formatted for PyPI/long description, I can update it accordingly.
