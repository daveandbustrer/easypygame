﻿# Blu Easy Pygame

A small wrapper for `pygame` that makes basic game setup easier.

`Blu_easy_pygame` provides:

- a simple `init()` function for window setup
- a single `run()` loop for frame updates
- callback binding for frame and input events
- shape classes for rectangles, circles, ellipses, lines, squares, and polygons

---

## Installation

Install `pygame` first, then install the package locally for development:

```bash
python -m pip install pygame
python -m pip install -e .
```

If published on PyPI, install with:

```bash
python -m pip install Blu_easy_pygame
```

---

## Quick Start

```python
import easypygame as epy

# 1. Initialize the window
epy.init(width=600, height=600, bg="white")

# 2. Create shapes
box = epy.graphics.rect(100, 100, 120, 80, color="red")
circle = epy.graphics.circle(300, 200, 50, color="blue")
line = epy.graphics.line([(50, 50), (200, 120)], width=4, color="green")
polygon = epy.graphics.polygon(
    [(350, 100), (420, 180), (320, 220)],
    color="purple"
)

# 3. Frame update function

def update(dt):
    box.x += 100 * dt
    if box.left > epy.getWidth():
        box.right = 0

# 4. Mouse callback

def on_left_click(event):
    print("Left click:", event)

# 5. Bind callbacks
epy.bind("mainLoop", update)
epy.bind("leftMouseDown", on_left_click)

# 6. Start the game loop
epy.run()
```

---

## Core API

### `epy.init(width=300, height=300, bg="white", background=None, frame=60, busy=False)`

Initialize `pygame`, configure the display, and set the background color.

Returns:

- `(passed, failed)` from `pygame.init()`

Arguments:

- `width` — window width in pixels
- `height` — window height in pixels
- `bg` — background color
- `background` — alias for `bg`
- `frame` — target frames per second
- `busy` — optional busy-mode flag

Example:

```python
epy.init(width=800, height=600, bg="black", frame=60)
```

### `epy.run()`

Start the main game loop. Shapes created with `epy.graphics` are drawn automatically each frame.

The loop continues until the window closes or `epy.stop()` is called.

Example:

```python
epy.run()
```

### `epy.bind(funcType, func)`

Register a callback for a supported event type.

Supported `funcType` values:

- `mainLoop` — called each frame, receives `dt` in seconds
- `physicsLoop` — called each frame, receives physics delta time in seconds
- `phisicLoop` — legacy alias for `physicsLoop`
- `mouseDown` — any mouse button press
- `mouseUp` — any mouse button release
- `leftMouseDown`, `leftMouseUp`
- `middleMouseDown`, `middleMouseUp`
- `rightMouseDown`, `rightMouseUp`
- `mouseMotion` — mouse movement
- `mouseWheel` — wheel scrolling
- `keyDown`, `keyUp`

Example:

```python
def update(dt):
    print("Delta time:", dt)

epy.bind("mainLoop", update)
```

Callbacks may accept a single parameter or no parameters.

Mouse callback example:

```python
def on_click(event):
    print("Mouse event:", event)

epy.bind("leftMouseDown", on_click)
```

### `epy.unbind(funcType)`

Remove a bound callback.

Example:

```python
epy.unbind("leftMouseDown")
```

### `epy.stop()`

Stop the game loop from inside a callback.

Example:

```python
def quit_game(dt):
    epy.stop()

epy.bind("mainLoop", quit_game)
```

### `epy.getWidth()` and `epy.getHeight()`

Return the window width and height.

Example:

```python
width = epy.getWidth()
height = epy.getHeight()
```

### `epy.getFPS()`

Return the current frame rate value.

Example:

```python
fps = epy.getFPS()
```

### `epy.getGameTime()`

Return the elapsed game time in milliseconds.

Example:

```python
elapsed = epy.getGameTime()
```

### `epy.getBackground()` and `epy.setBackground(color)`

Read or change the current background color.

Example:

```python
current = epy.getBackground()
epy.setBackground("black")
```

### `epy.sleep(milliseconds, processOS=True)`

Pause execution for the given time.

Example:

```python
epy.sleep(500)
```

---

## Shapes

Create shapes using `epy.graphics`. Shapes are drawn automatically each frame.

### `epy.graphics.rect(x, y, width, height, angle=0, color="black")`

Create a rectangle.

Example:

```python
rect = epy.graphics.rect(50, 50, 120, 80, angle=0, color="red")
```

### `epy.graphics.circle(x, y, radius, color="black")`

Create a circle.

Example:

```python
circle = epy.graphics.circle(200, 200, 50, color="blue")
```

### `epy.graphics.ellipse(x, y, width, height, angle=0, color="black")`

Create an ellipse.

Example:

```python
egg = epy.graphics.ellipse(300, 150, 160, 80, angle=0, color="green")
```

### `epy.graphics.square(x, y, radius, angle=0, color="black")`

Create a square.

Example:

```python
square = epy.graphics.square(150, 300, 50, angle=30, color="purple")
```

### `epy.graphics.line(points, width=1, color="black")`

Create a line path from points.

Example:

```python
line = epy.graphics.line([(50, 400), (200, 450), (300, 380)], width=3, color="yellow")
```

### `epy.graphics.polygon(points, width=0, angle=0, color="black")`

Create a polygon from a list of points.

Example:

```python
triangle = epy.graphics.polygon(
    [(350, 100), (420, 180), (320, 220)],
    color="purple"
)
```

Add more points later:

```python
triangle.add_point(380, 50)
```

---

## Shape Properties

Most shapes support these properties:

- `x`, `y`
- `left`, `right`, `top`, `bottom`
- `width`, `height` for rectangles and ellipses
- `radius` for circles and squares
- `points` for lines and polygons
- `angle` for rotated shapes
- `color`

Example:

```python
rect.x += 5
rect.color = "blue"
print(circle.radius)
```

---

## Event data

Mouse callbacks receive a parameter dictionary with values like:

- `pos` — mouse position
- `rel` — relative movement
- `buttons` — button state
- `touch` — touch input data
- `window` — window event data
- `x`, `y` — wheel delta values

Keyboard callbacks receive:

- `unicode`
- `key`
- `mod`
- `scancode`

Example:

```python
def on_click(event):
    print("Clicked:", event)
```

---

## Full example

```python
import easypygame as epy

epy.init(width=640, height=480, bg="lightgray")

player = epy.graphics.rect(50, 50, 50, 50, color="blue")
enemy = epy.graphics.polygon(
    [(400, 100), (460, 180), (340, 180)],
    color="red"
)


def update(dt):
    player.x += 120 * dt
    if player.left > epy.getWidth():
        player.right = 0


def on_click(event):
    print("Click event:", event)


epy.bind("mainLoop", update)
epy.bind("leftMouseDown", on_click)
epy.run()
```
